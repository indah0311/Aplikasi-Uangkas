-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 26 Jan 2024 pada 11.10
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `database_m.rafli_mauludin`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `Nim` varchar(30) NOT NULL,
  `Nama` varchar(50) NOT NULL,
  `Jenis_Kelamin` varchar(50) NOT NULL,
  `No_Hp` varchar(50) NOT NULL,
  `Alamat` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `mahasiswa`
--

INSERT INTO `mahasiswa` (`Nim`, `Nama`, `Jenis_Kelamin`, `No_Hp`, `Alamat`) VALUES
('22220095', 'Indah Cantikss', 'Perempuan', '08234567788', 'Samudera Atlantik'),
('22220099', 'Kiki', 'Laki - Laki', '081271436598', 'Silau Tua Bawah'),
('22221212', 'Amin', 'Laki - Laki', '08454665678776', 'alamat palsu'),
('22228088', 'jennie kim', 'Perempuan', '082254367654', 'Korea Utara');

-- --------------------------------------------------------

--
-- Struktur dari tabel `uangkas`
--

CREATE TABLE `uangkas` (
  `No` int(20) NOT NULL,
  `Tanggal` varchar(50) NOT NULL,
  `Nama` varchar(50) NOT NULL,
  `Keterangan` varchar(50) NOT NULL,
  `Pemasukan` varchar(100) NOT NULL,
  `Pengeluaran` varchar(100) NOT NULL,
  `Saldo_Akhir` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `uangkas`
--

INSERT INTO `uangkas` (`No`, `Tanggal`, `Nama`, `Keterangan`, `Pemasukan`, `Pengeluaran`, `Saldo_Akhir`) VALUES
(1, '2024-01-25', 'kiki ndutss', 'Uang Keluar', '5000', '3000', '2000'),
(2, '2024-01-25', 'Indah L', 'Uang Masuk', '100000', '20000', '80000'),
(4, '2024-01-25', 'jennie kim', 'Uang Masuk', '10000', '5000', '5000');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`Nim`);

--
-- Indeks untuk tabel `uangkas`
--
ALTER TABLE `uangkas`
  ADD PRIMARY KEY (`No`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
